<footer>
<div class="pull-right">
    &copy;2020 All Copyright Reserved.
</div>
<div class="clearfix"></div>
</footer>
