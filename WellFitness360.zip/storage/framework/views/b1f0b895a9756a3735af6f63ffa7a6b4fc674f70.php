
<?php $__env->startSection('content'); ?>
<div class="main_container">
    <?php echo $__env->make('backend.templates.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- top navigation -->
    <?php echo $__env->make('backend.templates.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /top navigation -->
    <!-- page content -->
    <div class="right_col" role="main">
        <div class="">
        </div>
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2><?php echo app('translator')->get('backend/list.forms.add_subscription_plan'); ?></h2>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <br />
                        <form id="subscriptionPlan" action="<?php echo e(route('SubscriptionPlanManagement.store')); ?>"  method="post" class="form-horizontal form-label-left">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?> ">
                            <div class="form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12"><?php echo app('translator')->get('backend/list.forms.duration'); ?></label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <select id="Duration" name="Duration" class="form-control">
                                        <option value="">Select Duration</option>
                                        <?php if($PlanDurations): ?>
                                            <?php $__currentLoopData = $PlanDurations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Duration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($Duration->id); ?>" <?php if(old('Duration') == $Duration->id): ?> selected <?php endif; ?>><?php echo e(ucwords($Duration->duration)); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                    <small class="text-danger"><?php echo e($errors->first('Duration')); ?></small>
                                </div>
                            </div>


                            <div class="form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="Title"><?php echo app('translator')->get('backend/list.forms.title'); ?> <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input type="text" name="Title" value="<?php echo e(old('Title')); ?>" id="Title" class="form-control col-md-7 col-xs-12" placeholder="Enter Title">
                                    <small class="text-danger"><?php echo e($errors->first('Title')); ?></small>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="Amount"><?php echo app('translator')->get('backend/list.forms.amount'); ?> <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input type="text" name="Amount" value="<?php echo e(old('Amount')); ?>" id="Amount" class="form-control col-md-7 col-xs-12" placeholder="Enter Plan Amount">
                                    <small class="text-danger"><?php echo e($errors->first('Amount')); ?></small>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12"><?php echo app('translator')->get('backend/list.forms.status'); ?></label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <select id="status" name="status" class="form-control">
                                        <option value="">Select Status</option>
                                        <option value="1" <?php if(old('status') == 1): ?> selected <?php endif; ?>>Active</option>
                                        <option value="2" <?php if(old('status') == 0): ?> selected <?php endif; ?>>InActive</option>
                                    </select>
                                    <small class="text-danger"><?php echo e($errors->first('status')); ?></small>
                                </div>
                            </div>
                            <div class="ln_solid"></div>
                            <div class="form-group">
                                <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                                    <button type="submit" class="btn btn-success"><?php echo app('translator')->get('backend/list.forms.submit'); ?></button>
                                    <button class="btn btn-primary" type="button" onclick="window.history.go(-1); return false;"><?php echo app('translator')->get('backend/list.forms.back'); ?></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /page content -->
<!-- footer content -->
<?php echo $__env->make('backend.templates.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- /footer content -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WellFitness360\resources\views/backend/SubscriptionPlan/add.blade.php ENDPATH**/ ?>