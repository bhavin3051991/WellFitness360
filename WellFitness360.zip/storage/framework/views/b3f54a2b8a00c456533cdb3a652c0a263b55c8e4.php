    <script src="<?php echo e(asset('backend/vendors/jquery/dist/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('backend/vendors/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
    <!-- Parsley -->
    <script src="<?php echo e(asset('backend/vendors/parsleyjs/dist/parsley.min.js')); ?>"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/additional-methods.min.js"></script>
    
    <script src="<?php echo e(asset('backend/toastr/toastr.min.js')); ?>"></script>
    
    <script src="<?php echo e(asset('backend/js/auth.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\WellFitness360\resources\views/auth/template/footer.blade.php ENDPATH**/ ?>