<footer>
<div class="pull-right">
    &copy;2020 All Copyright Reserved.
</div>
<div class="clearfix"></div>
</footer>
<?php /**PATH C:\xampp\htdocs\WellFitness360\resources\views/backend/templates/footer.blade.php ENDPATH**/ ?>