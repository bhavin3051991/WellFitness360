<?php echo $__env->make('auth.template.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div>
      <div class="login_wrapper">
        <div class="animate form login_form">
          <section class="login_content">
            <?php if(session()->has('success_msg')): ?>
            <div class="alert alert-success">
                <?php echo e(session()->get('success_msg')); ?>

            </div>
            <?php endif; ?>
            <?php if(session()->has('error_msg')): ?>
            <div class="alert alert-danger">
                <?php echo e(session()->get('error_msg')); ?>

            </div>
            <?php endif; ?>
            <form id="forgotePassword" method="POST">
                <input type="hidden" name="_token"  id="csrf-token" value="<?php echo e(csrf_token()); ?>">
                <h1>Forgot Password</h1>
                <div class="auth-input">
                    <input type="text" name="email" id="email" value="<?php echo e(old('email')); ?>" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="Email Address" required="" />
                </div>
                <div class="auth-input">
                    <button type="submit" class="btn btn btn-success forgotr-btn">Submit</button>
                </div>
                <div class="clearfix"></div>
                <div class="separator">
                    <p class="change_link">New to site?
                    <a href="<?php echo e(route('login')); ?>"> Login </a>
                    </p>

                    <div class="clearfix"></div>
                    <br />

                    <div>
                    <h1><i class="fa fa-paw"></i> WellFit360</h1>
                    <p>©2020 All Rights Reserved.</p>
                    </div>
                </div>
            </form>
          </section>
        </div>
      </div>
    </div>
<?php echo $__env->make('auth.template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\xampp\htdocs\WellFitness360\resources\views/auth/forgotePassword.blade.php ENDPATH**/ ?>