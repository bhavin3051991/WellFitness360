<html>
    <head>
        <title>User Crdential</title>
    </head>
    <body>
        <h3>Hi, <?php echo e($data['name']); ?></h3>
        <p><?php echo e($data['subject']); ?></p>
        <table border="2">

            <?php if(isset($data['name']) && !empty($data['name'])): ?>
            <tr>
                <th>Name</th>
                <td><?php echo e($data['name']); ?></td>
            </tr>
            <?php endif; ?>

            <?php if(isset($data['email']) && !empty($data['email'])): ?>
            <tr>
                <th>Email</th>
                <td><?php echo e($data['email']); ?></td>
            </tr>
            <?php endif; ?>

            <?php if(isset($data['password']) && !empty($data['password'])): ?>
            <tr>
                <th>Password</th>
                <td><?php echo e($data['password']); ?></td>
            </tr>
            <?php endif; ?>

            <?php if(isset($data['verifyUrl']) && isset($data['verifyToken']) && !empty($data['verifyUrl']) && !empty($data['verifyToken'])): ?>
            <tr>
                <th>Click Here to verify : </th>
                <td>
                    <a href="<?php echo e($data['verifyUrl']); ?>/<?php echo e($data['verifyToken']); ?>" target="_blank"><?php echo e($data['verifyToken']); ?></a>
                </td>
            </tr>
            <?php endif; ?>
        </table>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\WellFitness360\resources\views/email/sendCredential.blade.php ENDPATH**/ ?>