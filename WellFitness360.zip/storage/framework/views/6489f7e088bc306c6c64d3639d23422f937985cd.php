<div class="top_nav">
    <div class="nav_menu">
      <nav>
        <div class="nav toggle">
          <a id="menu_toggle"><i class="fa fa-bars"></i></a>
        </div>
        <div class="btn-group">
            <?php if(config('app.locale') =='en'): ?>
                
                <?php $langname = 'ENGLISH'; $img = 'us.svg'; ?>
            <?php elseif(config('app.locale') =='ar'): ?>
                
                <?php $langname = 'ARABIC'; $img = 'arabic.svg'; ?>
            <?php elseif(config('app.locale') =='de'): ?>
                
                <?php $langname = 'GERMAN'; $img = 'german.svg'; ?>
            <?php elseif(config('app.locale') =='no'): ?>
                
                <?php $langname = 'NORWAY'; $img = 'norway.svg'; ?>
            <?php endif; ?>
            <button data-toggle="dropdown" class="btn btn-default dropdown-toggle" type="button" aria-expanded="false">
                <img src="<?php echo e(asset('backend/images/'.$img)); ?>" title="English" width="20" alt="English">
                <?php echo e($langname); ?> <span class="caret"></span>
            </button>
            <ul role="menu" class="dropdown-menu">
              <li><a href="<?php echo e(route('lang.switch', 'en')); ?>" class="dropdown-item">ENGLISH</a></li>
              <li><a href="<?php echo e(route('lang.switch', 'ar')); ?>" class="dropdown-item">ARABIC</a></li>
              <li><a href="<?php echo e(route('lang.switch', 'no')); ?>" class="dropdown-item">NORWEGIAN</a></li>
              <li><a href="<?php echo e(route('lang.switch', 'de')); ?>" class="dropdown-item">GERMAN</a></li>
            </ul>
        </div>

        <ul class="nav navbar-nav navbar-right">
          <li class="">
            <a href="javascript:void(0);" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
              <img src="<?php echo e(asset('backend/images/img.jpg')); ?>" alt=""><?php echo e((Auth::user()) ? (Auth::user()->name).' '.(Auth::user()->sur_name) : ''); ?>

              <span class=" fa fa-angle-down"></span>
            </a>
            <ul class="dropdown-menu dropdown-usermenu pull-right">
              <!-- <li><a href="javascript:void(0);"><i class="fa fa-user pull-right"></i>Profile</a></li> -->
              <li><a href="<?php echo e(route('changePassword')); ?>"><i class="fa fa-lock pull-right"></i>Change Password</a></li>
              <li><a href="<?php echo e(url('logout')); ?>"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
            </ul>
          </li>
        </ul>
      </nav>
    </div>
  </div>
<?php /**PATH C:\xampp\htdocs\WellFitness360\resources\views/backend/templates/header.blade.php ENDPATH**/ ?>