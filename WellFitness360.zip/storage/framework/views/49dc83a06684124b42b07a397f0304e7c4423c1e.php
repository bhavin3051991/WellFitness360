

<?php $__env->startSection('content'); ?>

<div class="main_container">
    <?php echo $__env->make('backend.templates.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!-- top navigation -->
    <?php echo $__env->make('backend.templates.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /top navigation -->

    <!-- page content -->
    <div class="right_col" role="main">
        <div class="">
          <div class="page-title">
            <div class="title_left">
                <h3><?php echo app('translator')->get('backend/sidebar.trainer_categories_management'); ?></h3>
            </div>
            <div class="title_right">
              <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                
              </div>
            </div>
          </div>

          <div class="clearfix"></div>

          <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
              <div class="x_panel">
                <?php if(session()->has('success_msg')): ?>
                <div class="alert alert-success alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <?php echo e(session()->get('success_msg')); ?>

                </div>
                <?php endif; ?>

                <?php if(session()->has('error_msg')): ?>
                <div class="alert alert-danger alert-dismissible">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                    <?php echo e(session()->get('error_msg')); ?>

                </div>
                <?php endif; ?>
                <div class="x_title">
                  <h2>List</h2>
                  <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <a href="<?php echo e(route('trainercategoriesManagement.create')); ?>"<button type="button" class="btn btn-success">Add New Categories</button></a>
                    <div id="tree_1" class="tree-demo">
                        {<?php echo $showcat; ?>}
                    </div>


                </div>
              </div>
            </div>

          </div>
        </div>
      </div>
    <!-- /page content -->

    <!-- footer content -->
    <?php echo $__env->make('backend.templates.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /footer content -->
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WellFitness360\resources\views/backend/TrainercategoriesManagement/list.blade.php ENDPATH**/ ?>