
<?php $__env->startSection('content'); ?>
<div class="main_container">
    <?php echo $__env->make('backend.templates.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- top navigation -->
    <?php echo $__env->make('backend.templates.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- /top navigation -->
    <!-- page content -->
    <div class="right_col" role="main">
        <div class="">
        </div>
        <div class="clearfix"></div>
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                    <div class="x_title">
                        <h2><?php echo app('translator')->get('backend/list.forms.edit_subscription_plan'); ?></h2>
                        <ul class="nav navbar-right panel_toolbox">
                            <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                            </li>
                            <li class="dropdown">
                                <a href="javascript:void(0);" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                                <ul class="dropdown-menu" role="menu">
                                    <li><a href="javascript:void(0);">Settings 1</a>
                                    </li>
                                    <li><a href="javascript:void(0);">Settings 2</a>
                                    </li>
                                </ul>
                            </li>
                            <li><a class="close-link"><i class="fa fa-close"></i></a>
                            </li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="x_content">
                        <br />
                        <form id="userForm" action="<?php echo e(route('SubscriptionPlanManagement.update',$plan['id'])); ?>"  method="post" class="form-horizontal form-label-left">
                            <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?> ">
                             <?php echo e(method_field('PUT')); ?>

                             <div class="form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12"><?php echo app('translator')->get('backend/list.forms.duration'); ?></label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <select id="Duration" name="Duration" class="form-control">
                                        <option value="">Select Status</option>
                                        <?php if($PlanDurations): ?>
                                            <?php $__currentLoopData = $PlanDurations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Duration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($Duration->id); ?>" <?php if($plan['Duration_id'] == $Duration->id): ?> selected <?php endif; ?>><?php echo e(ucwords($Duration->duration)); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                    <small class="text-danger"><?php echo e($errors->first('Duration')); ?></small>
                                </div>
                            </div>


                            <div class="form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="Title"><?php echo app('translator')->get('backend/list.forms.title'); ?> <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input type="text" name="Title" value="<?php echo e(ucwords($plan['Title'])); ?>" id="Title" class="form-control col-md-7 col-xs-12" placeholder="Enter Title">
                                    <small class="text-danger"><?php echo e($errors->first('Title')); ?></small>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12" for="Amount"><?php echo app('translator')->get('backend/list.forms.amount'); ?> <span class="required">*</span>
                                </label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <input type="text" name="Amount" value="<?php echo e($plan['Amount']); ?>" id="Amount" class="form-control col-md-7 col-xs-12" placeholder="Enter Plan Amount">
                                    <small class="text-danger"><?php echo e($errors->first('Amount')); ?></small>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="control-label col-md-3 col-sm-3 col-xs-12"><?php echo app('translator')->get('backend/list.forms.status'); ?></label>
                                <div class="col-md-6 col-sm-6 col-xs-12">
                                    <select id="status" name="status" class="form-control">
                                        <option value="">Select Status</option>
                                        <option value="1" <?php if($plan['Status'] == 1): ?> selected <?php endif; ?>>Active</option>
                                        <option value="2" <?php if($plan['Status'] == 0): ?> selected <?php endif; ?>>InActive</option>
                                    </select>
                                    <small class="text-danger"><?php echo e($errors->first('Status')); ?></small>
                                </div>
                            </div>
                            <div class="ln_solid"></div>
                            <div class="form-group">
                                <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                                    <button type="submit" class="btn btn-success"><?php echo app('translator')->get('backend/list.forms.submit'); ?></button>
                                    <button class="btn btn-primary" type="button" onclick="window.history.go(-1); return false;"><?php echo app('translator')->get('backend/list.forms.back'); ?></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- /page content -->
<!-- footer content -->
<?php echo $__env->make('backend.templates.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- /footer content -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WellFitness360\resources\views/backend/SubscriptionPlan/edit.blade.php ENDPATH**/ ?>