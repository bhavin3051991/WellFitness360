
<?php $__env->startSection('content'); ?>
<div class="main_container">
	<?php echo $__env->make('backend.templates.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!-- top navigation -->
	<?php echo $__env->make('backend.templates.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!-- /top navigation -->
	<!-- page content -->
	<div class="right_col" role="main">
		<div class="">
			<div class="page-title">
				<div class="title_left">
					<h3><?php echo app('translator')->get('backend/list.categories'); ?></h3>
				</div>
				<div class="title_right">
					<div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
						<a href="<?php echo e(route('categoriesManagement.create')); ?>">
						<button type="button" class="btn btn-success add-new-btn"><?php echo app('translator')->get('backend/list.add_new'); ?></button>
						</a>
					</div>
				</div>
			</div>
			<div class="clearfix"></div>
			<div class="row">
				<div class="col-md-12 col-sm-12 col-xs-12">
					<div class="x_panel">
						<?php if(session()->has('success_msg')): ?>
						<div class="alert alert-success alert-dismissible">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
							<?php echo e(session()->get('success_msg')); ?>

						</div>
						<?php endif; ?>
						<?php if(session()->has('error_msg')): ?>
						<div class="alert alert-danger alert-dismissible">
                            <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
							<?php echo e(session()->get('error_msg')); ?>

						</div>
						<?php endif; ?>
						<div class="x_title">
							<h2><?php echo app('translator')->get('backend/list.list'); ?></h2>
							<div class="clearfix"></div>
						</div>
						<div class="x_content">
							<table id="datatable-buttons" class="table table-striped table-bordered">
								<thead>
									<tr>
										<th>No </th>
										<th>Categories Name</th>
										<th>Categories Description</th>
										<th>Categories Image</th>
										<th>Status</th>
										<th>Action</th>
									</tr>
								</thead>
								<tbody>
									<?php if($Categories): ?>
										<?php $__currentLoopData = $Categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<tr>
											<td><?php echo e($loop->iteration); ?></td>
											<td><?php echo e(ucfirst($value['cat_Name'])); ?></td>
											<td><?php echo e($value['cat_description']); ?></td>
											<td><img src="<?php echo e(asset($value['cat_image'])); ?>" alt="" width="75px;" height="75px;"></td>
											<td>
												<?php if($value['status'] == 1): ?>
													<span class="label label-success">Active</span>
												<?php else: ?>
													<span class="label label-danger">Inactive</span>
												<?php endif; ?>
											</td>
											<td>
												<a href="<?php echo e(route('categoriesManagement.edit',$value['ID'])); ?>"><i class="fa fa-edit"></i> Edit</a>
												<a href="javascript:void(0);" data-id="<?php echo e($value['ID']); ?>" class="deletCategories">
												<i class="fa fa-trash"></i> Delete
												</a>
											</td>
										</tr>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endif; ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- /page content -->
	<!-- footer content -->
	<?php echo $__env->make('backend.templates.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!-- /footer content -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\WellFitness360\resources\views/backend/categoriesManagement/categories_list.blade.php ENDPATH**/ ?>